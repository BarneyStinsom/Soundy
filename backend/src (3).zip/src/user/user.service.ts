import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { db } from '../prisma/db.js';
import type { Char } from '@prisma/orm-postgres/target/codec-types';

@Injectable()
export class UserService {
    async findAll(){
        return await db.orm.public.User
        .select('id', 'name', 'email', 'password')
        .all();
    }
    async findOne(id: string) {
    const user = await db.orm.public.User
        .select('id', 'name', 'email', 'pictureUrl')
        .where({ id })
        .first();

    if (!user) {
        throw new NotFoundException('Usuário não encontrado');
    }

    return user;
}
    async findPlaylists(id: string){
        const user = await db.orm.public.User
        .where({ id: id as Char<36> })
        .first();
        if (!user) {
            throw new NotFoundException('Usuário não encontrado');
        }
        return await db.orm.public.Playlist
        .where({ userId: id as Char<36> })
        .select('id', 'name', 'coverUrl')
        .all();
    }

    async create(name: string, email: string, password: string, isAdmin: boolean, pictureUrl?: string){
         const existing = await db.orm.public.User
        .where({ email })
        .first();

        if (existing) {
            throw new ConflictException('Já existe uma conta com esse email.');
        }
        return await db.orm.public.User.create({
            name,
            email,
            password,
            isAdmin,
            pictureUrl
        });
    }
    async update(id: string, name: string, email: string, password: string, isAdmin: boolean | undefined, pictureUrl: string | undefined){
        const user = await db.orm.public.User
        .where({ id: id as Char<36> })
        .first();
        if (!user) {
            throw new NotFoundException('Usuário não encontrado');
        }
        return await db.orm.public.User
        .where({ id: id as Char<36>})
        .update({
            name,
            email,
            password,
            isAdmin: isAdmin ?? user.isAdmin,
            pictureUrl,
        });
    }
    
    async delete(id: string){
        const user = await db.orm.public.User
        .where({ id: id as Char<36> })
        .first();
        if (!user) {
            throw new NotFoundException('Usuário não encontrado');
        }
        return await db.orm.public.User
        .where({ id: id as Char<36>})
        .delete();
    }
    
async login(email: string, password: string) {
  const user = await db.orm.public.User
    .where({ email })
    .first();

  if (!user || user.password !== password) {
    throw new NotFoundException('Email ou senha incorretos');
  }

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    isAdmin: user.isAdmin
  };
}
async UpdaPic(id: string, pictureUrl: string){
 const user = await db.orm.public.User
        .where({ id: id as Char<36> })
        .first();
        if (!user) {
            throw new NotFoundException('Usuário não encontrado');
        }
        return await db.orm.public.User
        .where({ id: id as Char<36>})
        .update({
            pictureUrl
        });
    }
}