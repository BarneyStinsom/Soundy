// pgMusicas.js — lista as músicas de uma playlist OU de um álbum/EP/single.
// Quem decide é o parâmetro "tipo" (ou "type") da URL:  pgMusicas.html?tipo=playlist&id=...
// Se o tipo não vier (só ?id=...), a página descobre sozinha se o id é de álbum ou de playlist.
// Cada linha abre o player (musica/pMusica.html) dentro desta coleção.
// Na playlist há uma busca embaixo da lista pra adicionar músicas.
// Depende de api.js (API_URL, userId, api, formatDuration)

const params = new URLSearchParams(window.location.search);
const tipo = (params.get('tipo') || params.get('type') || '').toLowerCase();
const id = params.get('id');

// Álbum, EP e single são todos "álbuns" no banco (o que muda é o campo type).
function kindFromTipo(value) {
    if (value === 'playlist') return 'playlist';
    if (['album', 'albuns', 'albums', 'ep', 'eps', 'single', 'singles'].includes(value)) return 'album';
    return null;
}

let kind = kindFromTipo(tipo); // 'playlist' | 'album' | null (null = descobrir pelo id)

const DEFAULT_COVER = 'imagens/Logo.png';

const backLink = document.querySelector('#backLink');
const message = document.querySelector('#message');
const content = document.querySelector('#content');
const titleEl = document.querySelector('#title');
const coverEl = document.querySelector('#cover');
const tipoText = document.querySelector('#tipoText');
const info = document.querySelector('#info');
const emptyText = document.querySelector('#emptyText');
const songList = document.querySelector('#songList');
const addSection = document.querySelector('#addSection');
const searchInput = document.querySelector('#searchInput');
const searchResults = document.querySelector('#searchResults');

let currentSongs = [];       // [{ rowId, position, id, title, duration, artist, cover }]
let allSongs = [];           // todas as músicas do sistema (pra buscar e adicionar)
let songById = new Map();    // id -> música, pra achar o artista de cada linha da playlist
let collectionCover = DEFAULT_COVER;

// ---------- PEÇAS DAS LINHAS ----------

function normalize(text) {
    // "Ação" e "acao" passam a ser iguais na busca
    return text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function createThumb(src) {
    const img = document.createElement('img');
    img.className = 'musica-capa';
    img.alt = '';
    img.onerror = () => { img.onerror = null; img.src = DEFAULT_COVER; };
    img.src = src || collectionCover;
    return img;
}

function createInfo(title, artist) {
    const box = document.createElement('div');
    box.className = 'musica-info';

    const strong = document.createElement('strong');
    strong.textContent = title;
    box.appendChild(strong);

    if (artist) {
        const span = document.createElement('span');
        span.textContent = artist;
        box.appendChild(span);
    }
    return box;
}

function createDuration(seconds) {
    const span = document.createElement('span');
    span.className = 'musica-duracao';
    span.textContent = formatDuration(seconds ?? 0);
    return span;
}

// ---------- CARREGAR CONFORME O TIPO ----------

// Cada loader devolve { title, subtitle, cover, songs } no mesmo formato.

async function loadPlaylist() {
    const mine = await api(`/users/${userId}/playlists`);
    const playlist = mine.find((p) => p.id === id);
    if (!playlist) throw new Error('Playlist não encontrada.');

    return {
        title: playlist.name,
        subtitle: 'playlist',
        cover: playlist.coverUrl,
        songs: await loadPlaylistSongs(),
    };
}

// A API responde 404 quando a playlist existe mas está vazia — aqui vira lista vazia.
async function loadPlaylistSongs() {
    let items = [];
    try {
        items = await api(`/playlists/${id}/songs`);
    } catch (error) {
        if (error.status !== 404) throw error;
    }

    return items
        .sort((a, b) => a.position - b.position)
        .map((item) => ({
            rowId: item.id, // id da linha em playlistsongs (usado pra remover)
            position: item.position,
            id: item.song?.id,
            title: item.song?.title ?? 'Música removida',
            duration: item.song?.duration ?? 0,
            artist: songById.get(item.song?.id)?.artist?.name,
            cover: item.song?.songCoverUrl,
        }));
}

async function loadAlbum() {
    const album = await api(`/albums/${id}`);
    if (!album) throw new Error('Álbum não encontrado.'); // a API devolve vazio quando não existe

    let songs = [];
    try {
        songs = await api(`/albums/${id}/songs`);
    } catch (error) {
        if (error.status !== 404) throw error; // 404 = álbum sem músicas
    }

    const artistName = album.artist?.name;
    return {
        title: album.title,
        subtitle: artistName ? `${album.type} — ${artistName}` : album.type,
        cover: album.coverUrl,
        songs: songs.map((song, index) => ({
            position: index + 1,
            id: song.id,
            title: song.title,
            duration: song.duration,
            artist: artistName, // todas as músicas do álbum são do artista do álbum
            cover: song.songCoverUrl,
        })),
    };
}

// ---------- MOSTRAR NA TELA ----------

function render(data) {
    currentSongs = data.songs;
    collectionCover = data.cover || DEFAULT_COVER;

    document.title = `${data.title} — Soundy`;
    titleEl.textContent = data.title;
    tipoText.textContent = data.subtitle;

    coverEl.alt = `Capa de ${data.title}`;
    coverEl.onerror = () => { coverEl.onerror = null; coverEl.src = DEFAULT_COVER; };
    coverEl.src = collectionCover;

    const total = currentSongs.reduce((sum, song) => sum + song.duration, 0);
    info.textContent = currentSongs.length === 0
        ? 'Nenhuma música'
        : `${currentSongs.length} ${currentSongs.length === 1 ? 'música' : 'músicas'} — ${formatDuration(total)} no total`;

    emptyText.hidden = currentSongs.length > 0;
    renderSongs();
    content.hidden = false;
}

function renderSongs() {
    songList.replaceChildren();

    currentSongs.forEach((song) => {
        const row = document.createElement('div');
        row.className = 'musica';
        row.append(createThumb(song.cover), createInfo(song.title, song.artist), createDuration(song.duration));

        // clicar na linha abre o player; tipo e coleção fazem "Anterior" e "Próxima" seguirem esta lista
        const playUrl = `musica/pMusica.html?id=${encodeURIComponent(song.id)}&tipo=${kind}&colecao=${encodeURIComponent(id)}`;
        row.addEventListener('click', () => { window.location.href = playUrl; });

        // só a playlist permite tirar músicas
        if (kind === 'playlist') {
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'btn-remover';
            removeBtn.textContent = '✕';
            removeBtn.title = 'Remover da playlist';
            removeBtn.addEventListener('click', (event) => {
                event.stopPropagation(); // sem isso o clique também abriria o player
                removeSong(song);
            });
            row.appendChild(removeBtn);
        }

        songList.appendChild(row);
    });
}

// ---------- PLAYLIST: BUSCAR, ADICIONAR E REMOVER ----------

function renderSearch() {
    searchResults.replaceChildren();

    const query = normalize(searchInput.value.trim());
    if (!query) return; // sem texto, sem resultados

    const inPlaylist = new Set(currentSongs.map((song) => song.id));
    const matches = allSongs
        .filter((song) => !inPlaylist.has(song.id))
        .filter((song) => normalize(`${song.title} ${song.artist?.name ?? ''}`).includes(query))
        .slice(0, 8);

    if (matches.length === 0) {
        const empty = document.createElement('p');
        empty.textContent = 'Nenhuma música encontrada.';
        searchResults.appendChild(empty);
        return;
    }

    matches.forEach((song) => {
        const row = document.createElement('div');
        row.className = 'musica';
        row.append(createThumb(song.songCoverUrl), createInfo(song.title, song.artist?.name), createDuration(song.duration));

        const addBtn = document.createElement('button');
        addBtn.type = 'button';
        addBtn.className = 'btn-adicionar';
        addBtn.textContent = '+ Adicionar';
        addBtn.addEventListener('click', () => addSong(song, addBtn));
        row.appendChild(addBtn);

        searchResults.appendChild(row);
    });
}

searchInput.addEventListener('input', renderSearch);

async function reloadPlaylist(notice = '') {
    render(await loadPlaylist());
    renderSearch(); // a música adicionada some dos resultados
    message.textContent = notice;
}

async function addSong(song, button) {
    const position = currentSongs.reduce((max, s) => Math.max(max, s.position), 0) + 1;
    button.disabled = true;

    try {
        await api('/playlistsongs', {
            method: 'POST',
            body: JSON.stringify({ playlistId: id, songId: song.id, position }),
        });
        await reloadPlaylist('Música adicionada.');
    } catch (error) {
        message.textContent = error.message;
        button.disabled = false;
    }
}

async function removeSong(song) {
    try {
        await api(`/playlistsongs/${song.rowId}`, { method: 'DELETE' });
        await reloadPlaylist('Música removida da playlist.');
    } catch (error) {
        message.textContent = error.message;
    }
}

// ---------- DESCOBRIR O TIPO PELO ID ----------

// A API devolve vazio em /albums/:id quando o álbum não existe; aí testa as playlists do usuário.
async function detectKind() {
    const album = await api(`/albums/${id}`);
    if (album) return 'album';

    const mine = await api(`/users/${userId}/playlists`);
    if (mine.some((playlist) => playlist.id === id)) return 'playlist';

    return null;
}

// ---------- INICIALIZAÇÃO ----------

async function init() {
    if (!id) {
        message.textContent =
            'Endereço inválido: falta o id. Use pgMusicas.html?tipo=album&id=... ou ?tipo=playlist&id=...';
        return;
    }

    message.textContent = 'Carregando...';

    try {
        if (!kind) {
            kind = await detectKind();
            if (!kind) throw new Error('Não encontrei nenhum álbum ou playlist com esse id.');
        }

        // o botão "Voltar" leva pra lista de onde a pessoa veio
        backLink.href = kind === 'playlist' ? 'playlist/pPlaylists.html' : 'menu/menu.html';

        if (kind === 'playlist') {
            allSongs = (await api('/songs')) || [];
            songById = new Map(allSongs.map((song) => [song.id, song]));
            await reloadPlaylist();
            addSection.hidden = false;
        } else {
            render(await loadAlbum());
            message.textContent = '';
        }
    } catch (error) {
        message.textContent = error.message;
    }
}

if (userId) {
    init();
}